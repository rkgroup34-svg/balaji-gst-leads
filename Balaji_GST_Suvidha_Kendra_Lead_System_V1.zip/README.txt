Balaji GST Suvidha Kendra — Lead Management V1
- Registration fee: ₹99
- Lead fields: Name, Mobile, Email, Location, Source
- Flow: New Lead → Interested → ₹99 Payment Pending → ₹99 Paid → Ready to Process → Open BO
- Company KYC/app/onboarding remains in the company panel.
- Demo stores leads locally in the browser (localStorage). This is not production-grade multi-user storage.
- Replace the demo payment/WhatsApp/company-panel actions with verified production integrations before public launch.
